package com.company;

public class ConcatLight extends ExpregBinaire{
    public ConcatLight(Expreg exp1, Expreg exp2) {
        super(exp1,"",exp2);
    }
}
