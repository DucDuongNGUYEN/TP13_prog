package com.company;

public interface Expreg {
    String toString();
}
