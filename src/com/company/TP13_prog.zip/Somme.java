package com.company;

public class Somme extends ExpregBinaire{
    public Somme(Expreg exp1, Expreg exp2){
        super(exp1," + ",exp2);
    }
}
